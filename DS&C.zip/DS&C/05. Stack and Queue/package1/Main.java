package package1;

public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        int n = 5;
        Fun fun = new Fun();
        fun.haveFun();
        System.out.println("Finishing main "+n);
    }
}
